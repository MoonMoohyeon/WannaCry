import json
from collections import defaultdict

# 1) STIX JSON 로드
with open("enterprise-attack.json", "r", encoding="utf-8") as f:
    stix_bundle = json.load(f)

objects = stix_bundle.get("objects", [])

# 2) Malware 오브젝트 매핑: ID -> 이름
#    (모든 type=="malware" 객체를 대상으로)
malware_id_to_name = {}
for obj in objects:
    if obj.get("type") == "malware":
        m_id = obj.get("id")
        m_name = obj.get("name", "")
        if m_id and m_name:
            malware_id_to_name[m_id] = m_name

# 3) Attack-Pattern 오브젝트 매핑:
#    STIX 내 UUID -> (TID, [kill_chain_phases 목록])
attack_pattern_id_to_tid = {}
attack_pattern_id_to_phases = {}

for obj in objects:
    if obj.get("type") == "attack-pattern":
        ap_id = obj.get("id")
        ext_refs = obj.get("external_references", [])
        tid = None
        for ext in ext_refs:
            if ext.get("source_name") == "mitre-attack" and ext.get("external_id", "").startswith("T"):
                tid = ext.get("external_id")
                break
        if not tid:
            # "TID를 못 찾은 기법"은 Navigator에 넣어도 의미가 없으므로 건너뜀
            continue

        # kill_chain_phases 배열에서 mitre-attack 체인에 속한 phase_name들만 수집
        phases = []
        for phase in obj.get("kill_chain_phases", []):
            if phase.get("kill_chain_name") == "mitre-attack":
                pn = phase.get("phase_name")
                if pn:
                    phases.append(pn)
        # phases가 비어 있으면 "unknown" 처리하거나 빈 리스트로 둬도 됨
        attack_pattern_id_to_tid[ap_id] = tid
        attack_pattern_id_to_phases[ap_id] = phases

# 4) Relationship(type="uses")에서 Malware -> Attack-Pattern 관계 추출
technique_to_malware = defaultdict(set)

for obj in objects:
    if obj.get("type") == "relationship" and obj.get("relationship_type") == "uses":
        src = obj.get("source_ref")   # e.g. "malware--uuid"
        tgt = obj.get("target_ref")   # e.g. "attack-pattern--uuid"
        if src in malware_id_to_name and tgt in attack_pattern_id_to_tid:
            tid = attack_pattern_id_to_tid[tgt]
            m_name = malware_id_to_name[src]
            technique_to_malware[tid].add(m_name)

# 5) 기법별 Malware 개수(score) 계산 및 최대값 파악
technique_counts = { tid: len(malware_set) for tid, malware_set in technique_to_malware.items() }

if technique_counts:
    max_count = max(technique_counts.values())
else:
    max_count = 0

# 6) 기법별 첫 번째 Tactic(=kill_chain_phases[0]) 가져오기
technique_to_phases = {}
for ap_id, tid in attack_pattern_id_to_tid.items():
    phases = attack_pattern_id_to_phases.get(ap_id, [])
    if phases:
        # 여러번 같은 TID가 나오므로, "가장 첫 번째 phase"로 덮어써도 결과가 크게 다르지 않음
        technique_to_phases[tid] = phases[0]
    else:
        technique_to_phases[tid] = "unknown"

# 7) Navigator Layer JSON 템플릿 생성
#    "score" 필드는 기법별 Malware 개수(count)
#    gradient.minValue=0, gradient.maxValue=max_count
#    각 기법의 tactic은 technique_to_phases[tid]
navigator_layer = {
    "name": "Malware Overlap Heatmap",
    "versions": {
        "attack": "11",         # STIX 데이터 버전과 일치시키거나, 변경 가능
        "navigator": "5.1.0",   # ATT&CK Navigator 버전
        "layer": "4.5"          # Layer 사양 버전
    },
    "domain": "enterprise-attack",
    "description": "여러 악성코드가 중복 사용하는 기법을 진하게 표시하는 Heatmap",
    "filters": {
        "platforms": [
            "Windows",
            "Linux",
            "macOS",
            "PRE",
            "Containers",
            "Network",
            "Office 365",
            "SaaS",
            "Google Workspace",
            "IaaS",
            "Azure AD"
        ]
    },
    "sorting": 0,
    "layout": {
        "layout": "flat",
        "aggregateFunction": "sum",
        "showID": True,
        "showName": True,
        "showAggregateScores": True,
        "countUnscored": False,
        "expandedSubtechniques": "none"
    },
    "hideDisabled": False,
    "techniques": [],
    "gradient": {
        # minValue=0, maxValue=기법별 최대 중복 횟수(max_count)로 설정하여,
        # “score=0”은 가장 옅은 색, “score=max_count”는 가장 진한 색이 되도록 함
        "colors": ["#ffffff", "#ff6666"],  
        "minValue": 0,
        "maxValue": max_count
    },
    "legendItems": [
        {
            "label": f"0개 (흰색)",
            "color": "#ffffff"
        },
        {
            "label": f"{max_count}개 (진한 빨강)",
            "color": "#ff6666"
        }
    ],
    "metadata": [],
    "links": [],
    "showTacticRowBackground": False,
    "tacticRowBackground": "#dddddd",
    "selectTechniquesAcrossTactics": True,
    "selectSubtechniquesWithParent": False,
    "selectVisibleTechniques": False
}

# 8) techniques 배열 채우기
for tid, count in technique_counts.items():
    tactic = technique_to_phases.get(tid, "unknown")
    navigator_layer["techniques"].append({
        "techniqueID": tid,
        "tactic": tactic,
        "score": count,
        "color": "",          # 비워두면 gradient 기반으로 Navigator가 자동 색 지정
        "comment": f"Used by {count} malware samples",
        "enabled": True,
        "metadata": [],
        "links": [],
        "showSubtechniques": False
    })

# 9) JSON 파일로 저장
output_filename = "malware_overlap_heatmap_layer.json"
with open(output_filename, "w", encoding="utf-8") as fout:
    json.dump(navigator_layer, fout, indent=2, ensure_ascii=False)

print(f"'{output_filename}' 생성 완료! (기법 수: {len(navigator_layer['techniques'])}, 최대 중복 횟수: {max_count})")
